﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChildCollision : MonoBehaviour
{
    public bool isTouching = false;
    public BoxCollider2D colliderObject;
    public LayerMask mask;

    //void OnCollisionEnter2D(Collision2D collision) {
    //    if (collision.gameObject.tag == "ChildGround") {
    //        isTouching = true;
    //        //print(isTouching);
    //    }
    //}

    //public bool isColliding() {
    //    print("Is colliding  " + colliderObject.IsTouchingLayers(mask));
    //    return colliderObject.IsTouchingLayers(mask);
    //}

    //void OnTriggerEnter2D(Collider2D collision) {
    //    if (collision.gameObject.tag == "ChildGround") {
    //        isTouching = true;
    //        print(isTouching + "  trigger");
    //    }
    //}
}
