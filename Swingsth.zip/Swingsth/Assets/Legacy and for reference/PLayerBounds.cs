﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PLayerBounds : MonoBehaviour
{

    public float borderX = 10f, borderY = 5.5f;
    private bool outOfBounds = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        CheckBounds();
    }

    void CheckBounds() {
        Vector2 temp = transform.position;
        if (temp.x > borderX || temp.x < -borderX)
            outOfBounds = true;
        if (temp.y > borderY || temp.y < -borderY)
            outOfBounds = true;
        if (outOfBounds) {
            GameManager.instance.RestartGame();
        }
    }
}
