﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platforms_Script : MonoBehaviour
{
    public float Speed = 2f;
    private float YBorder = 8f;
    public float movingPlatformSpeed = 1.5f;

    public bool movingR, movingL, breakable, spikey, daefult;

    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        if (breakable)
            anim = GetComponent<Animator>();


    }
    // Update is called once per frame
    void Update()
    {
        Move();
    }

    void Move() {
        Vector2 temp = transform.position;
        temp.y += Speed * Time.deltaTime;
        transform.position = temp;

        if (temp.y >= YBorder)
            gameObject.SetActive(false);
    }

    void BreakableDeactivate() {
        Invoke("DeactiavateGameObject", 0.7f);
    }

    void DeactiavateGameObject() {
        gameObject.SetActive(false);
    }

    void OnTriggerEnter2D(Collider2D target) {
        if (target.tag == "Player") {
            if (spikey) {
                target.transform.position = new Vector2(100f, 100f);
            }
        }
    }

    void OnCollisionEnter2D(Collision2D target) {
        if (target.gameObject.tag == "Player") {
            if (breakable) {
                //Sound
                anim.Play("Break");
            }
            if (daefult) {
                //sound
            }
        }
    }
    
    //void OnCollisionStay2D(Collision2D target) {
    //    if (target.gameObject.tag == "Player") {
    //        if (movingL) {
    //            target.gameObject.GetComponent<Movement>().PlatformMove(-movingPlatformSpeed);
    //        }
    //        if (movingR) {
    //            target.gameObject.GetComponent<Movement>().PlatformMove(movingPlatformSpeed);
    //        }
    //    }
    //}
}
