﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{

    public GameObject platformPrefab;
    public GameObject spikePlatformPrefab;
    public GameObject[] movingPlatformPrefab;
    public GameObject breakablePlatformPrefab;

    private float Timer = 1.3f;
    public float currentTimer;

    public int spawnCount = 0;

    public float minX = -6f, maxX = 6f;
    // Start is called before the first frame update
    void Start()
    {
        currentTimer = Timer;
    }

    // Update is called once per frame
    void Update()
    {
        Timer = Random.Range(1f, 4f);
        SpawnPlatforms();
    }

    void SpawnPlatforms() {
        currentTimer += Time.deltaTime;

        if (currentTimer >= Timer) {
            spawnCount++;
            Vector3 temp = transform.position;
            temp.x = Random.Range(minX, maxX);

            GameObject newPlatform = null;

            if (spawnCount < 3) {
                newPlatform = Instantiate(platformPrefab, temp, Quaternion.identity);
            }
            else if (spawnCount == 3) {
                if (Random.Range(0, 2) > 0) {
                    newPlatform = Instantiate(breakablePlatformPrefab, temp, Quaternion.identity);
                }
                else {
                    newPlatform = Instantiate(movingPlatformPrefab[Random.Range(0, movingPlatformPrefab.Length)], temp, Quaternion.identity);
                }
            }
            else if (spawnCount == 4) {
                if (Random.Range(0, 2) > 0) {
                    newPlatform = Instantiate(breakablePlatformPrefab, temp, Quaternion.identity);
                }
                else {
                    newPlatform = Instantiate(spikePlatformPrefab, temp, Quaternion.identity);
                }
            }
            else if (spawnCount >= 5) {
                if (Random.Range(0, 2) > 0) {
                    newPlatform = Instantiate(platformPrefab, temp, Quaternion.identity);
                }
                else {
                    newPlatform = Instantiate(breakablePlatformPrefab, temp, Quaternion.identity);
                }
                spawnCount = 0;
            }
            newPlatform.transform.parent = transform;
            currentTimer = 0f;
        } //spawn a platform
    }
    
}
