﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGscroll : MonoBehaviour
{
    public float scroll_speed = 0.2f;
    private MeshRenderer mesh_Render;
    string texture = "_MainTex";
    // Start is called before the first frame update
    void Start()
    {
        mesh_Render = GetComponent<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        Scroll();
    }

    void Scroll() {
        Vector2 offset = mesh_Render.sharedMaterial.GetTextureOffset(texture);
        offset.y += Time.deltaTime * scroll_speed;

        mesh_Render.sharedMaterial.SetTextureOffset(texture, offset);
    }
}
