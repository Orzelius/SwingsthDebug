﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class TimerScript : MonoBehaviour
{
    public float time = 0;
    public Text myText;

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        string timeStr = time.ToString();
        myText.text = timeStr.Substring(0, timeStr.IndexOf(",") + 3);
    }
}
