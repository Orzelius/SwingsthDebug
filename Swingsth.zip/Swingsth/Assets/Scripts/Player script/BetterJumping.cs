﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BetterJumping : MonoBehaviour
{
    public Rigidbody2D rb;

    [Header("Stats")]
    public float jumpSpeed = 3f;
    public float fallSpeed = 2f;
    public float fallSpeedMultiplier = 2.5f;
    public float lowJumpMultiplier = 4f;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //print(Input.GetAxisRaw("Vertical"));
        if (rb.velocity.y < 0) {
            rb.velocity += Vector2.up * Physics2D.gravity.y * (fallSpeedMultiplier - 1) * Time.deltaTime;
        }
        else if (rb.velocity.y > 0 && !(Input.GetAxisRaw("Jump") > 0f)) {
            rb.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;
        }
        if (Input.GetAxisRaw("Vertical") < 0f) {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y - fallSpeed);
        }
    }
}
