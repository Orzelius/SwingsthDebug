﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Drawing;

public class SpawnerNew : MonoBehaviour {
    private BoxCollider2D objectCollider;

    [Header("Spawn Parameters")]
    public float[] blockSizeRangesX;
    public float[] blockSizeRangesY;
    public float[] spawnPositionRangesX = new float[2];
    public float[] spawnPositionRangesY = new float[2];
    public int[] spawnAmmountRangesPerLayer;
    public float layersPerY;
    public int layers;
    public int[] checkForTouch;

    public GameObject blockPrefab;
    public GameObject worldBorder;

    public float horzExtent;
    public List<GameObject> platforms = new List<GameObject>();
    public bool platformsSpawned = false;

    void Update() {
        if (!platformsSpawned) {
            SpawnPlatforms();
            platformsSpawned = true;
        }
        print(checkTouchFunc(checkForTouch[0], platforms[checkForTouch[1]]));
    }

    void SpawnPlatforms() {
        horzExtent = worldBorder.GetComponent<Transform>().localScale.x / 2;
        spawnPositionRangesX[1] = worldBorder.GetComponent<Transform>().localScale.x;
        spawnPositionRangesX[0] = -spawnPositionRangesX[1];
        spawnPositionRangesY[1] = worldBorder.GetComponent<Transform>().localScale.y;
        spawnPositionRangesY[0] = -spawnPositionRangesY[1];
        //int layers = (int)(spawnPositionRangesY[0] * layersPerY);

        float layerThickness = spawnPositionRangesY[1] / layers * 2;

        for (int layer = 0; layer < layers; layer++) {
            int spawnAmount = Random.Range(spawnAmmountRangesPerLayer[0], spawnAmmountRangesPerLayer[1]);
            for (int x = 0; x < spawnAmount; x++) {
                int attempts = 0;
                bool touching = true;
                while (touching) {  //  && attempts < 200
                    attempts++;
                    if (attempts > 200) {
                        print("Stuck in a loop");
                        return;
                    }

                    Vector3 size = new Vector3(
                        Random.Range(blockSizeRangesX[0], blockSizeRangesX[1]),
                        Random.Range(blockSizeRangesY[0], blockSizeRangesY[1]),
                        1);

                    Vector3 spawnPoint = new Vector3(
                        Random.Range(spawnPositionRangesX[0], spawnPositionRangesX[1]),
                        Random.Range(spawnPositionRangesY[0] + (layer * layerThickness), spawnPositionRangesY[0] + layer * layerThickness),
                        0);

                    GameObject newPlatform = Instantiate(blockPrefab, spawnPoint, Quaternion.identity, this.transform);
                    newPlatform.name = (platforms.Count).ToString();
                    newPlatform.layer = LayerMask.NameToLayer("Ground");
                    newPlatform.transform.localScale = size;

                    touching = false;
                    for (int y = 0; y < platforms.Count && !touching; y++) {
                        print(newPlatform.name + "  " + checkTouchFunc(y, newPlatform) + " against " + (y));
                        if (checkTouchFunc(y, newPlatform)) {
                            print("");
                            touching = true;
                        }
                    }

                    if (touching) {
                        Destroy(newPlatform);
                    }
                    else {
                        platforms.Add(newPlatform);
                    }
                }
            } //layerSpawn
        } //allLayerSpawn
    }

    bool checkTouchFunc(int object1, GameObject object2) {
        return(platforms[object1].GetComponent<BoxCollider2D>().bounds.Intersects(object2.GetComponent<BoxCollider2D>().bounds));
    }
}