﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Variables")]
    public GameObject target;
    public float smoothSpeed;
    public float maxOffsetY;
    public float camMoveTime;

    [Header("Offsets")]
    public Vector3 offsetStanding;
    //public Vector3 offsetLooking;
    public Vector3 offsetFalling;

    private Vector3 velocity = Vector3.zero;
    private Transform targetPos;
    private Rigidbody2D rb;
    private Vector3 offset;
    private float timeSinceChange = 10f;
    private int offsetChanged = 0;
    private int lastOffset = 0;
    private bool timerActive = false;

    void Start() {
        targetPos = target.GetComponent<Transform>();
        rb = target.GetComponent<Rigidbody2D>();
    }

    void FixedUpdate() {
        if (timerActive)
            timeSinceChange += Time.deltaTime;

        if (rb.velocity.y < -1.5f && offset.y > -maxOffsetY) {
            offsetChanged = -1;
            if (offsetChanged != lastOffset) {
                timerActive = true;
                timeSinceChange = 0f;
            }
            else if(timeSinceChange > camMoveTime) {
                offset -= offsetFalling * Time.deltaTime;
                timerActive = false;
            }
        }
        else if (rb.velocity.y < 0.3f && rb.velocity.y > -0.3f) {
            offsetChanged = 0;
            offset = offsetStanding;
        }
        lastOffset = offsetChanged;

        //print(offsetChanged);
        Vector3 desiredPos = targetPos.position + offset;
        transform.position = Vector3.SmoothDamp(transform.position , desiredPos, ref velocity, smoothSpeed);
    }
}
